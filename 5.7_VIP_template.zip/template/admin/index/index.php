<?php if (!defined('ADMIN')) exit('Can\'t Access !'); ?>
 
<style>

.i_box {
width:100%;
border:1px solid #ccc;
border-radius: 3px;  
background:white;
text-align:left;
}
.i_box ul {padding:20px 10px;}
.i_box ul li {
height:38px;line-height:38px;
}
.i_box h5 {height:38px;
line-height:38px;
margin:0px;
padding:0px 20px;
background:#eee;
font-size:1.0em;
}



.quick-btn {min-height:83px; margin:0px 10px 35px 5px; padding:5px 0px; background: #d9edf7;border:1px solid #bce8f1;
    color: #3a87ad; border-radius:2px; text-align:center;}
	
.quick-btn a {display:block; height:83px; line-height:122px; color: #3a87ad;background:url({$skin_path}/images/q-1.png) center 12px no-repeat;}
.quick-btn a.q2 {background:url({$skin_path}/images/q-2.png) center 8px no-repeat;
}
.quick-btn a.q3 {background:url({$skin_path}/images/q-3.png) center 8px no-repeat;
}
.quick-btn a.q4 {margin:0px; background:url({$skin_path}/images/q-4.png) center 8px no-repeat;
}
.quick-btn a.q5 {background:url({$skin_path}/images/q-5.png) center 8px no-repeat;
}

.quick-btn:hover {background:#c4e3f5;}



.list-group-item {margin:0px 10px 10px 10px; }
.list-group-item:last-child {border-radius:2px; }

a.list-group-item-info {border-color: #bce8f1;
    color: #3a87ad;
	}

a.list-group-item-warning {
    border-color: #fbeed5;
    color: #c09853;
	}

a.list-group-item-success {
    border-color: #d6e9c6;
    color: #468847;
	}

a.list-group-item-danger {
	    border-color: #eed3d7;
    color: #b94a48;
	}

@media(max-width:468px) {
a.list-group-item-success,a.list-group-item-danger {
margin-top:10px;
}
.system-info,.i_table_b,.information {display:none;}
}


.table {margin:0px;}
.table a.btn {margin:0px 10px 0px 0px;padding:3px 5px; background: #4993c6; color:white; font-size:0.8em; }
.website-a {font-weight:bold;padding:0px 10px 0px 0px;}

.i_links_bg {line-height:200%; border-top:5px solid #fffbc1; padding:15px 20px;background:#fffcdf;}
.i_table_b ul {padding:12px 20px;}
.i_table_b strong {padding:3px 10px; background: #d9edf7;border:1px solid #bce8f1;color: #3a87ad; border-radius:2px;}


.blank25 {clear:both; height:25px;}

</style>

<div class="blank20"></div>




<div class="row" style="padding:0px 3px 0px 5px;">

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3" style="padding:0px;">
<a title="点击查看" href="{$base_url}/index.php?case=table&act=list&table=archive&admin_dir={get('admin_dir')}&site=default" class="list-group-item list-group-item-info"><span class="glyphicon glyphicon-file"></span> 内容	{$archivenum}</a>
</div>



<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3" style="padding:0px;">
<a title="点击查看" href="{$base_url}/index.php?case=table&act=list&table=comment&admin_dir={get('admin_dir')}&site=default" class="list-group-item list-group-item-warning">
<span class="glyphicon glyphicon-comment"></span> 评论	{$commentnum}</a>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3" style="padding:0px;">
<a title="点击查看" href="{$base_url}/index.php?case=table&act=list&table=guestbook&admin_dir={get('admin_dir')}&site=default" class="list-group-item list-group-item-success"><span class="glyphicon glyphicon-list-alt"></span> 留言	{$guestbooknum}</a>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3" style="padding:0px;">
<a title="点击查看" href="{$base_url}/index.php?case=table&act=list&table=orders&admin_dir={get('admin_dir')}&site=default" class="list-group-item list-group-item-danger">
<span class="glyphicon glyphicon-shopping-cart"></span> 订单	{$ordernum}</a>
</div>

</div>

<div class="blank25"></div>

<div class="row">

<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<div class="row quick-box">
<div style="padding:0px 0px 0px 10px;">

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=config&act=system&set=site&admin_dir={get('admin_dir')}&site=default" class="q1">网站设置</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=table&act=add&table=archive&admin_dir={get('admin_dir')}&site=default" class="q2">添加内容</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=table&act=list&table=orders&admin_dir={get('admin_dir')}&site=default" class="q3">订单管理</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=cache&act=make_show&admin_dir={get('admin_dir')}&site=default" class="q4">生成HTML</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=config&act=remove&admin_dir={get('admin_dir')}&site=default" class="q5">更新缓存</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=table&act=list&table=category&admin_dir={get('admin_dir')}&site=default" class="q6">栏目管理</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=table&act=list&table=type&admin_dir={get('admin_dir')}&site=default" class="q7">分类管理</a>
</div>
</div>

<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
<div class="quick-btn">
<a href="{$base_url}/index.php?case=table&act=list&table=usergroup&admin_dir={get('admin_dir')}&site=default" class="q8">用户组管理</a>
</div>
</div>

</div>
</div>
</div>

<div class="system-info col-xs-12 col-sm-6 col-md-6 col-lg-6">

<table class="table table-striped table-bordered table-hover">
<tr>
<td width="25%" align="right">服务器环境：</td>
<td width="75%"><?php echo $_SERVER['SERVER_SOFTWARE'];?> php:<?php echo PHP_VERSION;?> <?php echo config::get('database','type').':'.$dbversion;?></td>
</tr>

<tr>
<td align="right">服务器IP：</td>
<td><?php echo $_SERVER['SERVER_ADDR']?$_SERVER['SERVER_ADDR']:$_SERVER['LOCAL_ADDR'];?></td>
</tr>

<tr>
<td align="right">当前网站语言：</td>
<td><?php echo config::get('lang_type');?></td>
</tr>

<tr>
<td align="right">集团网站：</td>
<td>
{loop getwebsite() $d}<a href="{$d[addr]}" target="_blank" class="website-a"><span>{$d[name]}</span></a>{/loop}
</td>
</tr>

<tr>
<td align="right">系统版本：</td>
<td><span><?php echo _VERSION;?></span></td>
</tr>
</table>


</div>
</div>


<div class="clearfix"></div>

